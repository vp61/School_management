<?php

// Set Active toggle for actual navigation group
public static function set_toggle($stdId,$feeHeadId)
{
    $arrVal['TotalVal'] =  123456;
    $arrVal['TotalPaid'] =  56;
    return $arrVal;
}