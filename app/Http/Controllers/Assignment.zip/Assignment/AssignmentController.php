<?php

namespace App\Http\Controllers\Assignment;

use App\Http\Controllers\CollegeBaseController;
use App\Http\Requests\Assignment\AddValidation;
use App\Http\Requests\Assignment\EditValidation;
use App\Models\Assignment;
use App\Models\AssignmentAnswer;
use App\Models\Book;
use App\Models\BookCategory;
use App\Models\BookStatus;
use App\Models\Faculty;
use App\Models\HomeWork;
use App\Models\Semester;
use App\Models\Student;
use App\Models\Subject;
use App\Models\Year;
use App\Session_Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use URL;
use Carbon,Session;
use ViewHelper;
use DB,Auth;
/*--teacher access--*/
use App\Models\TeacherCoordinator;
/*--teacher access--*/
class AssignmentController extends CollegeBaseController
{
    protected $base_route = 'assignment';
    protected $view_path = 'assignment';
    protected $panel = 'Assignment';
    protected $folder_path;
    protected $filter_query = [];

    public function __construct()
    {
        $this->folder_path = public_path().DIRECTORY_SEPARATOR.'assignments'.DIRECTORY_SEPARATOR.'questions'.DIRECTORY_SEPARATOR;
    }

    public function index(Request $request)
    {

        
        $data = [];
        if($request->all()) {
            /*--teacher access--*/
                $classTeacher= TeacherCoordinator::where('teacher_id',Auth::user()->hook_id)
                ->where('branch_id',session::get('activeBranch'))
                ->where('record_status',1)
                ->where('session_id',Session::get('activeSession'))->pluck('section_id')->toArray();
                
                
                $classTeacherCourse = $this->getClassTeacherCourse();
                
                
                $ability = $this->getAbility();
            
            if(auth()->user()->hasRole('staff')) {
                $id = auth()->user()->id;
                $data['assignment'] = Assignment::select('assignments.id', 'assignments.created_by', 'assignments.last_updated_by', 'years_id', 'semesters_id', 'subjects_id', 'publish_date',
                    'end_date', 'title', 'description', 'file', 'assignments.status', 'faculties.faculty')->leftJoin('faculties', function($join){
                        $join->on('assignments.faculty', '=', 'faculties.id');
                    })
                    ->where('assignments.created_by',$id)
                    ->where('assignments.branch_id', session('activeBranch'))
                    ->where('session_id', session('activeSession'))
                    ->where(function ($query) use ($request) {
                        if ($request->year && $request->year > 0) {
                            $query->where('years_id', '=', $request->year);
                            $this->filter_query['years_id'] = $request->year;
                        }
                        if($request->faculty){
                            $query->where('assignments.faculty', '=', $request->faculty);
                            $this->filter_query['faculty'] = $request->faculty;
                        }
                        if ($request->semesters_id && $request->semesters_id != "" && $request->semesters_id > 0) {
                            $query->where('semesters_id', '=', $request->semesters_id);
                            $this->filter_query['semesters_id'] = $request->semesters_id;
                        }

                        if ($request->subjects_id && $request->subjects_id != "" && $request->subjects_id > 0) {
                            $query->where('subjects_id', '=', $request->subjects_id);
                            $this->filter_query['subjects_id'] = $request->subjects_id;
                        }

                        if ($request->publish_date_start != "" && $request->publish_date_end != "") {
                            $query->whereBetween('publish_date', [$request->publish_date_start, $request->publish_date_end]);
                            $this->filter_query['publish_date_start'] = $request->publish_date_start;
                            $this->filter_query['publish_date_end'] = $request->publish_date_end;
                        } elseif ($request->publish_date_start != "") {
                            $query->where('publish_date', '>=', $request->publish_date_start);
                            $this->filter_query['publish_date_start'] = $request->publish_date_start;
                        }
                    })
                     /*--teacher access--*/
                    ->Where(function($q)use($classTeacher,$ability){
                         if((count($classTeacher)>0) && (!$ability)){
                            $q->whereIn('assignments.semesters_id',$classTeacher);
                         }
                    })
                   /*--teacher access--*/
                    ->orderBy('assignments.id', 'Desc')//->latest()
                    ->get();
            }else{
                $data['assignment'] = Assignment::select('assignments.id', 'assignments.created_by', 'assignments.last_updated_by', 'years_id', 'semesters_id', 'subjects_id', 'publish_date',
                    'end_date', 'title', 'description', 'file', 'assignments.status', 'faculties.faculty')->leftJoin('faculties', function($join){
                        $join->on('assignments.faculty', '=', 'faculties.id');
                    })
                    ->where('assignments.branch_id', session('activeBranch'))
                    ->where('session_id', session('activeSession'))
                    ->where(function ($query) use ($request) {
                        
                        if ($request->year && $request->year > 0) {
                            $query->where('years_id', '=', $request->year);
                            $this->filter_query['years_id'] = $request->year;
                        }
                        if($request->faculty){
                            $query->where('assignments.faculty', '=', $request->faculty);
                            $this->filter_query['faculty'] = $request->faculty;
                        }
                        if ($request->semesters_id && $request->semesters_id != "" && $request->semesters_id > 0) {
                            $query->where('semesters_id', '=', $request->semesters_id);
                            
                            $this->filter_query['semesters_id'] = $request->semesters_id;
                        }

                        if ($request->subjects_id && $request->subjects_id != "" && $request->subjects_id > 0) {
                            $query->where('subjects_id', '=', $request->subjects_id);
                            $this->filter_query['subjects_id'] = $request->subjects_id;
                        }

                        if ($request->publish_date_start != "" && $request->publish_date_end != "") {
                            $query->whereBetween('publish_date', [$request->publish_date_start, $request->publish_date_end]);
                            $this->filter_query['publish_date_start'] = $request->publish_date_start;
                            $this->filter_query['publish_date_end'] = $request->publish_date_end;
                        } elseif ($request->publish_date_start != "") {
                            $query->where('publish_date', '>=', $request->publish_date_start);
                            $this->filter_query['publish_date_start'] = $request->publish_date_start;
                        }
                    })
                     /*--teacher access--*/
                    ->Where(function($q)use($classTeacher,$ability){
                         if((count($classTeacher)>0) && (!$ability)){
                            $q->whereIn('assignments.semesters_id',$classTeacher);
                         }
                    })
                  /*--teacher access--*/
                    ->orderBy('assignments.id', 'Desc')//->latest()
                    ->get();
            }
        }else{
            if(auth()->user()->hasRole('staff')) {
                $id = auth()->user()->id;
                $data['assignment'] = Assignment::select('assignments.id', 'assignments.created_by', 'assignments.last_updated_by', 'years_id', 'semesters_id', 'subjects_id', 'publish_date',
                    'end_date', 'title', 'description', 'file', 'assignments.status', 'faculties.faculty')->leftJoin('faculties', function($join){
                        $join->on('assignments.faculty', '=', 'faculties.id');
                    })
                    ->where('assignments.created_by',$id)
                    ->where('assignments.branch_id', session('activeBranch'))
                    ->where('session_id', session('activeSession'))
                    ->orderBy('assignments.id', 'Desc')//->latest()
                    ->limit(50)
                    ->get();
            }else {
                $data['assignment'] = Assignment::select('assignments.id', 'assignments.created_by', 'assignments.last_updated_by', 'years_id', 'semesters_id', 'subjects_id', 'publish_date',
                    'end_date', 'title', 'description', 'file', 'assignments.status', 'faculties.faculty')->leftJoin('faculties', function($join){
                        $join->on('assignments.faculty', '=', 'faculties.id');
                    })
                    ->orderBy('assignments.id', 'Desc')//->latest()
                    ->where('assignments.branch_id', session('activeBranch'))
                    ->where('session_id', session('activeSession'))
                    ->limit(50)
                    ->get();
            }
        }

        /*--teacher access--*/
        $data['faculties'] = $this->activeFaculties();

        $data['semester'] = $this->getClassTeacherSection();
        /*--teacher access--*/

        $data['years'] = [];
        $data['years'][0] = 'Select Year';
        foreach (Year::Active()->get() as $year) {
            $data['years'][$year->id] = $year->title;
        }


        $data['url'] = URL::current();
        $data['filter_query'] = $this->filter_query;

        return view(parent::loadDataToView($this->view_path.'.index'), compact('data'));
    }
 
    public function add(Request $request)
    {
        $data = [];
          /*--teacher access--*/
        $data['semester'] = $this->getClassTeacherSection();
        /*subject list*/
         $data['subjects']= ['--select--'];
        /*subject list*/
        $data['faculties'] = $this->activeFaculties();
          /*--teacher access--*/
       

        $data['url'] = URL::current();
        return view(parent::loadDataToView($this->view_path.'.add'), compact('data'));
    }

    public function store(AddValidation $request)
    {
         //dd($request->all());
        $year = Year::where('active_status',1)->first()->id;
        if ($request->hasFile('attach_file')){
            $name = str_slug($request->get('title'));
            $file = $request->file('attach_file');
            $file_name = rand(4585, 9857).'_'.$name.'.'.$file->getClientOriginalExtension();
            $file->move($this->folder_path, $file_name);
        }else{
            $file_name = "";
        }

        $request->request->add(['created_by' => auth()->user()->id]);
        $request->request->add(['years_id' => $year]);
        $request->request->add(['file' => $file_name]);
        $request->request->add(['branch_id'=>session('activeBranch')]);
        $request->request->add(['session_id'=>session('activeSession')]);
        
        Assignment::create($request->all());

        $request->session()->flash($this->message_success, $this->panel. ' Add Successfully.');
        return redirect($this->base_route);
    }


    public function edit(Request $request, $id)
    {
        $id = Crypt::decryptString($id);
        $data = [];
        $data['row'] = Assignment::find($id);
        //dd($data['row'] );

        if (!$data['row'])
            return parent::invalidRequest();

         $data['faculties'] = $this->activeFaculties();

         $data['semester'] = $this->getClassTeacherSection();
        /*subject list*/
        $data['subjects'] = DB::table('timetable_subjects')
        ->where('status',1)
        ->where('course_id',$data['row']->faculty)
        ->where('section_id',$data['row']->semesters_id)
        ->where('branch_id',session::get('activeBranch'))
        ->where('session_id',session::get('activeSession'))
        ->pluck('title','id')->toArray();
        //dd($data['subjects']);
        /*subject list*/
        $data['url'] = URL::current();
        $data['base_route'] = $this->base_route;
        return view(parent::loadDataToView($this->view_path.'.edit'), compact('data'));
    }

    public function update(EditValidation $request, $id)
    {

        if (!$row = Assignment::find($id)) return parent::invalidRequest();

        if ($request->hasFile('attach_file')) {
            $name = str_slug($request->get('title'));
            $file = $request->file('attach_file');
            $file_name = rand(4585, 9857).'_'.$name.'.'.$file->getClientOriginalExtension();
            $file->move($this->folder_path, $file_name);


            if (file_exists($this->folder_path.$row->file))
                @unlink($this->folder_path.$row->file);
        }

        $year = Year::where('active_status',1)->first()->id;

        $request->request->add(['years_id' => $year]);
        $request->request->add(['last_updated_by' => auth()->user()->id]);
        $request->request->add(['file' => isset($file_name)?$file_name:$row->file]);

        $row->update($request->all());

        $request->session()->flash($this->message_success, $this->panel.' Updated Successfully.');
        return redirect($this->base_route);
    }

    public function view(Request $request, $id)
    {
        $id = Crypt::decryptString($id);
        $data = [];
        if(auth()->user()->hasRole('staff')) {
            $UserId = auth()->user()->id;
            $data['assignment'] = Assignment::find($id);
            if($data['assignment']->created_by != $UserId){
                return parent::invalidRequest();
            }
        }else{
            $data['assignment'] = Assignment::find($id);
        }
        $data['answers'] = $data['assignment']->answers()->select('assignment_answers.id','assignment_answers.answer_text',
                        'assignment_answers.file','assignment_answers.approve_status','assignment_answers.status',
                        's.reg_no','s.id as students_id','s.first_name',
                        's.middle_name','s.last_name','s.student_image')
                        ->join('students as s','s.id','=','assignment_answers.students_id')
                        ->get();
        return view(parent::loadDataToView($this->view_path.'.detail.index'), compact('data'));
    }

    public function delete(Request $request, $id)
    {
        $id = Crypt::decryptString($id);
        if (!$row = Assignment::find($id)) return parent::invalidRequest();

        if(auth()->user()->hasRole('staff')) {
            $UserId = auth()->user()->id;
            if($row->created_by != $UserId){
                return parent::invalidRequest();
            }
        }

        // remove old file from folder
        if ($row->file && file_exists($this->folder_path.$row->file)) {
            @unlink($this->folder_path.$row->file);
        }

        $row->delete();
        $request->session()->flash($this->message_success, $this->panel.' Deleted Successfully.');
        return redirect()->route($this->base_route);
    }

    public function bulkAction(Request $request)
    {
        if ($request->has('bulk_action') && in_array($request->get('bulk_action'), ['active', 'in-active', 'delete'])) {

            if ($request->has('chkIds')) {
                foreach ($request->get('chkIds') as $row_id) {
                    switch ($request->get('bulk_action')) {
                        case 'active':
                        case 'in-active':
                            $row = Assignment::find($row_id);
                            if ($row) {
                                $row->status = $request->get('bulk_action') == 'active'?'active':'in-active';
                                $row->save();
                            }
                            break;
                        case 'delete':
                            $row = Assignment::find($row_id);
                            // remove old file from folder
                            if (file_exists($this->folder_path.$row->file))
                                @unlink($this->folder_path.$row->file);

                            $row->delete();
                            break;
                    }
                }

                if ($request->get('bulk_action') == 'active' || $request->get('bulk_action') == 'in-active')
                    $request->session()->flash($this->message_success, $request->get('bulk_action'). ' Action Successfully.');
                else
                    $request->session()->flash($this->message_success, ' Deleted successfully.');

                return redirect()->route($this->base_route);

            } else {
                $request->session()->flash($this->message_warning, 'Please, Check at least one row.');
                return redirect()->route($this->base_route);
            }

        } else return parent::invalidRequest();

    }

    public function active(request $request, $id)
    {
        $id = Crypt::decryptString($id);
        if (!$row = Assignment::find($id)) return parent::invalidRequest();

        $request->request->add(['status' => 'active']);

        $row->update($request->all());
        // $row->faculty.' '.
        $request->session()->flash($this->message_success, $this->panel.' Active Successfully.');
        return redirect()->route($this->base_route);
    }

    public function inActive(request $request, $id)
    {
        $id = Crypt::decryptString($id);
        if (!$row = Assignment::find($id)) return parent::invalidRequest();

        $request->request->add(['status' => 'in-active']);

        $row->update($request->all());

        $request->session()->flash($this->message_success, $this->panel.' In-Active Successfully.');
        return redirect()->route($this->base_route);
    }



    public function findSemester(Request $request)
    {
        $response = [];
        $response['error'] = true;

        if ($request->has('faculty_id')) {
            $faculty = Faculty::select('faculties.id','faculties.faculty', 'faculties.slug', 'faculties.status','fs.semester_id','fs.faculty_id')
                ->where('faculties.id','=',$request->faculty_id)
                ->join('faculty_semester as fs', 'faculties.id', '=', 'fs.faculty_id')
                ->join('semesters as s', 'fs.semester_id', '=', 's.id')
                ->first();

            if ($faculty) {

                $response['semester'] = $faculty->semester()->select('semesters.id', 'semesters.semester')->get();

                $response['error'] = false;
                $response['success'] = 'Semester/Sec. Available For This Faculty/Class.';
            } else {
                $response['error'] = 'No Any Semester Assign on This Faculty/Class.';
            }

        } else {
            $response['message'] = 'Invalid request!!';
        }
        return response()->json(json_encode($response));
    }

    public function findSubject(Request $request)
    {
        


        //$semester = Semester::where('id',$request->get('semester_id'))->first();

        // if(auth()->user()->hasRole('staff')){
        //     $id = auth()->user()->hook_id;

        //     /*Find Teacher/Staff Accessible Subject*/
        //     $collectSubject = $semester->subjects()->select('subjects.id as subject_id','subjects.title as subject_title')
        //        // ->where('subjects.staff_id',$id)
        //         ->get();
        //     $subjects = array_pluck($collectSubject,'subject_title','subject_id');
        // }else{
        //     /*Find Subject Title with associated Ids*/
        //     $collectSubject = $semester->subjects()->select('subjects.id as subject_id','subjects.title as subject_title')->get();
        //     $subjects = array_pluck($collectSubject,'subject_title','subject_id');
        // }


          /*subject list*/
            
        $subjects= DB::table('timetable_subjects')->select('id','title')
        ->where('course_id',$request->faculty_id)
        ->where('section_id',$request->semester_id)
        ->where('branch_id',$request->branch_id)
        ->where('session_id',$request->session_id)
        ->where('status',1)
        ->get();

         
        if (count($subjects)>0) {
            $response['subjects'] = $subjects;
            $response['success'] = 'Subjects Found, Select Subject and Manage Question.';
        }else {
            $response['error'] = 'No Any Subject Found. Please Contact Your Administrator.';
        }

        return response()->json(json_encode($response));
    }


    /*answer*/
    public function viewAnswer(Request $request, $id, $answer)
    {
        $data = [];
        $data['assignment'] = Assignment::find($id);

        if(auth()->user()->hasRole('staff')) {
            $UserId = auth()->user()->id;
            if($data['assignment']->created_by != $UserId){
                return parent::invalidRequest();
            }
        }

        $data['answers'] = $data['assignment']->answers()->where('assignment_answers.id',$answer)
            ->select('assignment_answers.created_by','assignment_answers.last_updated_by','assignment_answers.id','assignment_answers.answer_text',
            'assignment_answers.file','assignment_answers.approve_status','assignment_answers.status','s.id as students_id')
            ->join('students as s','s.id','=','assignment_answers.students_id')
            ->first();

        if(!$data['answers']) return back()->with('message_warning','No Answer Submitted');

        $data['student'] = Student::select('students.id','students.reg_no', 'students.reg_date', 'students.university_reg',
            'students.faculty','students.semester', 'students.academic_status', 'students.first_name', 'students.middle_name',
            'students.last_name', 'students.date_of_birth', 'students.gender', 'students.blood_group', 'students.nationality',
            'students.mother_tongue', 'students.email', 'students.extra_info', 'students.student_image', 'students.status')
            ->where('students.id','=',$data['answers']->students_id)
            ->first();
       $data['teachercomments']=DB::table('assignment_comments')->select('comment','assignment_comments.created_at','member_type','member_name')
            ->where([
                ['assignment_id','=',$data['assignment']->id],
                ['answer_id','=',$data['answers']->id]
            ]) 
            ->get(); 
        if(isset($_POST['comment'])){
                 $date = Carbon\Carbon::now();
                 $userId=auth()->user()->hook_id;
                 $role=auth()->user()->role_id;
                 if($role==6){
                    $member_type=1;
                 }else{
                    $member_type=2;
                 }
            
            $data['comment']=DB::table('assignment_comments')->insert([
            'created_at' =>$date,
            'member_type'=>$member_type,
            'member_id'=>$userId,
            'assignment_id'=>$data['assignment']->id,
            'answer_id'=>$data['answers']->id,
            'comment'=>$request->comment,
            'member_name'=>auth()->user()->name
             ]);
            return back();
            }
        return view(parent::loadDataToView($this->view_path.'.answer.index'), compact('data'));
    }

    public function approveAnswer(request $request, $id)
    {
        if (!$row = AssignmentAnswer::find($id)) return parent::invalidRequest();

        $request->request->add(['approve_status' => 1]);

        $row->update($request->all());

        $request->session()->flash($this->message_success,'Assignment Answer Approve Successfully.');
        return back();
    }

    public function rejectAnswer(request $request, $id)
    {
        if (!$row = AssignmentAnswer::find($id)) return parent::invalidRequest();

        $request->request->add(['approve_status' => 2]);

        $row->update($request->all());

        $request->session()->flash($this->message_success,'Assignment Answer Rejected Successfully.');
        return back();
    }

    public function deleteAnswer(Request $request, $id)
    {
        if (!$row = AssignmentAnswer::find($id)) return parent::invalidRequest();

        $folder_path = public_path().DIRECTORY_SEPARATOR.'assignments'.DIRECTORY_SEPARATOR.'answers'.DIRECTORY_SEPARATOR;
        // remove old file from folder
        if ($row->file && file_exists($folder_path.$row->file)) {
            @unlink($folder_path.$row->file);
        }

        $row->delete();
        $request->session()->flash($this->message_success, $this->panel.' Deleted Successfully.');
        return redirect()->route($this->base_route);
    }

    public function bulkActionAnswer(Request $request)
    {
        if ($request->has('bulk_action') && in_array($request->get('bulk_action'), ['Approve', 'Reject', 'Delete'])) {

            if ($request->has('chkIds')) {
                foreach ($request->get('chkIds') as $row_id) {
                    switch ($request->get('bulk_action')) {
                        case 'Approve':
                            $row = AssignmentAnswer::find($row_id);
                            if ($row) {
                                $row->approve_status = 1;
                                $row->save();
                            }
                            break;
                        case 'Reject':
                            $row = AssignmentAnswer::find($row_id);
                            if ($row) {
                                $row->approve_status = 2;
                                $row->save();
                            }
                            break;
                        case 'Delete':
                            $row = AssignmentAnswer::find($row_id);
                            // remove old file from folder
                            if($row) {
                                $folder_path = public_path().DIRECTORY_SEPARATOR.'assignments'.DIRECTORY_SEPARATOR.'answers'.DIRECTORY_SEPARATOR;
                                if (file_exists($folder_path . $row->file))
                                    @unlink($folder_path . $row->file);

                                $row->delete();
                            }
                            break;
                    }
                }

                if ($request->get('bulk_action') == 'Approve')
                    $request->session()->flash($this->message_success, ' Answers Approve Successfully.');
                elseif ($request->get('bulk_action') == 'Reject' )
                    $request->session()->flash($this->message_success, 'Answers Rejected Successfully.');
                else
                    $request->session()->flash($this->message_success, 'Answers Deleted successfully.');

                return back();

            } else {
                $request->session()->flash($this->message_warning, 'Please, Check at least one row.');
                return back();
            }

        } else return parent::invalidRequest();

    }

    public function Getsubject($id)
    {

        $subject= DB::table('timetable_subjects')->select('title','id')->where('id',$id)->first();
        //dd($subject);
        if($subject){
            $subjectname= $subject->title;
        }
        else{
            $subjectname= "Unknown";
        }
        return $subjectname;
    }
}
