<h4 class="header large lighter blue"><i class="fa fa-list"></i> {{$panel}} List</h4>
<table id="dynamic-table" class="table table-striped table-hover">
	<thead>
		<th>S.No.</th>
		<th>Subject</th>
		<th>Is Practical</th>
		<th>Subject Type</th>
		<th>Edit / Delete</th>
	</thead>
	
	@php($i=1)
		@foreach($data['addsubject'] as $key=>$val)
		
			<tr>
				<td>{{$i}}</td>
				<td>{{$val->title}}</td>
				<td><?php
				    $s= $val->is_practical;
				    
				    if($s==0){
				    	echo "NO";
				    }
				    else{
				    	echo "YES";
				    }

				 ?></td>
				 <td><?php
				    
				    
				    if($val->is_main_subject==1){
				    	echo "MAIN";
				    }
				    else{
				    	echo "OPTIONAL";
				    }
				    
				   
				 ?></td>
				<td><a href="{{route($base_route.'.edit',[$val->id])}}" title="Edit"><i class="fa fa-pencil" style="color: green;"></i></a>
				@ability('super-admin','super-admin')	
				  <a href="{{route($base_route.'.delete',[$val->id])}}" title="Delete"><i class="fa fa-trash-o" style="color: red;"></i></a>
				@endability  
				</td>
			</tr>
			@php($i++)
		@endforeach
	
</table>